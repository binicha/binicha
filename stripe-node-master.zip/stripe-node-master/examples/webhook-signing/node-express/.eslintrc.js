module.exports = {
  parserOptions: {
    ecmaVersion: 6,
    sourceType: 'module',
  },
  rules: {
    'new-cap': 'off',
    'no-console': 'off',
  },
};
